struct CaptionOption {
    let emoji: String
    let caption: String
}
