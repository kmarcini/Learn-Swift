//: ## Wrapup
//: In this playground you’ve had a quick tour of playgrounds and the results sidebar. You’ve also learned a number of things to get you on the road to programming:
//: - Doing mathematical calculations
//: - Using comments
//: - Troubleshooting errors when things go wrong
//:
//: Congratulations!
//:
/*:
 _Copyright (C) 2016 Apple Inc. All Rights Reserved.\
 See LICENSE.txt for this sample’s licensing information_
 */
//:[Previous](@previous)  |  page 7 of 7
