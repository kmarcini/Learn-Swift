public func rowTheBoat() {
    print("Row, row, row your boat")
    print("Gently down the stream")
}
public func merrilyDream() {
    print("Merrily, merrily, merrily, merrily")
    print("Life is but a dream")
}
public func crocodileScream() {
    print("If you see a crocodile")
    print("Don't forget to scream")
}
public func repetitiveTheme() {
    print("This song is quite repetitive")
    print("Can you spot the theme")
}
public func breatheBetweenVerses() {
    print("        ~        ")
}
public func verseOne() {
    rowTheBoat()
    merrilyDream()
}
public func verseTwo() {
    rowTheBoat()
    crocodileScream()
}
public func verseThree() {
    rowTheBoat()
    repetitiveTheme()
}

