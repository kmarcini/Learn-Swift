/*:
 ## Personal Meme
 
 Copy the functions you made in the previous exercise to this page if you like or write them out again for practice. Or even make a whole new set.
 
 Inside one of the functions, make changes that make the whole text mean something different, or make it funnier. You could change a name to your name or a friend’s, change a word to something else that rhymes, or just play around.
*/




















/*:
 _Copyright (C) 2016 Apple Inc. All Rights Reserved.\
 See LICENSE.txt for this sample’s licensing information_
 */
//: [Previous](@previous)  |  page 12 of 12
